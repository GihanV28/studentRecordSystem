# I declare that my work contains no examples of misconduct, such as plagiarism, or collusion. 
# Any code taken from other sources is referenced within my code solution. 
# Student ID: IIT-20210185    UOW-w1867428
# Date: 12/8/2021

pass_credits = 0
defer_credits = 0
fail_credits = 0

progress = []
trailer = []
retriever = []
exclude = []


number_range = [ 0, 20, 40, 60, 80, 100, 120]

    
def progress_outcome_only(pass_credits, defer_credits):    
    if pass_credits == 120:
        print("Progress\n")
    elif pass_credits == 100:   
        print("Progress (module trailer)\n")
    elif pass_credits == 80:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 60:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 40 and defer_credits == 0:
        print("Exclude\n")
    elif pass_credits == 40 and defer_credits != 0:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 20 and defer_credits <=20:
        print("Exclude\n")
    elif pass_credits == 20 and defer_credits >=40:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 0 and defer_credits >= 60:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 0 and defer_credits <= 40:
        print("Exclude\n")   
    
def progress_outcome(pass_credits, defer_credits):    
    if pass_credits == 120:
        print("Progress\n")
    elif pass_credits == 100:   
        print("Progress (module trailer)\n")
    elif pass_credits == 80:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 60:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 40 and defer_credits == 0:
        print("Exclude\n")
    elif pass_credits == 40 and defer_credits != 0:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 20 and defer_credits <=20:
        print("Exclude\n")
    elif pass_credits == 20 and defer_credits >=40:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 0 and defer_credits >= 60:
        print("Do not Progress - module retriever\n")
    elif pass_credits == 0 and defer_credits <= 40:
        print("Exclude\n")



    

def histogram(pass_credits, defer_credits):
    
    if pass_credits == 120:
        progress.append(0)
    elif pass_credits == 100:
        trailer.append(0)
    elif pass_credits == 80:
        retriever.append(0)
    elif pass_credits == 60:
        retriever.append(0)
    elif pass_credits == 40 and defer_credits != 0:
        retriever.append(0)
    elif pass_credits == 40 and defer_credits == 0:
        exclude.append(0)
    elif pass_credits == 20 and defer_credits >= 40:
        retriever.append(0)
    elif pass_credits == 20 and defer_credits <= 20:
        exclude.append(0)
    elif pass_credits == 0 and defer_credits >= 60:
        retriever.append(0)
    elif pass_credits == 0 and defer_credits <= 40:
        exclude.append(0)


        
def validation():
    global pass_credits, defer_credits, fail_credits
    while True:
        try:
            pass_credits = int(input("Please enter your credits at pass: "))
        except ValueError:
            print ("Integer required\n")
        else:
            if pass_credits not in number_range:
                print("Out of range\n")
            elif pass_credits in number_range:
                break
    while True:
        try:
            defer_credits = int(input("Please enter your credits at defer: "))
        except ValueError:
            print ("Integer required\n")
        else:
            if defer_credits not in number_range:
                print("Out of range\n")
            elif defer_credits in number_range:
                break
    while True:
        try:
            fail_credits = int(input("Please enter your credits at fail: "))
        except ValueError:
            print ("Integer required\n")
        else:
            if fail_credits not in number_range:
                print("Out of range\n")
            elif fail_credits in number_range:
                break
    while True:
        total_credits_value = pass_credits + defer_credits + fail_credits
        if total_credits_value != 120:
            print("Total incorrect\n")
            validation()
            break
        else:
            progress_outcome(pass_credits, defer_credits)
            histogram(pass_credits, defer_credits)
            break

def histogram_output():
    print("\n")
    print("-" * 60)
    print("Horizontal Histogram\n")
    print("Progress", len(progress), " :", "*" * len(progress))
    print("Trailer", len(trailer), "  :", "*" * len(trailer))
    print("Retriever", len(retriever), ":", "*" * len(retriever))
    print("Excluded", len(exclude), " :", "*" * len(exclude))
    total_outcomes = len(progress) + len(trailer) + len(retriever) + len(exclude)
    print("\n")
    print(total_outcomes, "outcomes in total.")
    print("-" * 60)


quit_command = ""


def another_one():
    global quit_command
    while True:
        print("\n")
        try:
            quit_command = input("Would you like to enter another set of data?\n"
                          "Enter 'y' for yes or 'q' to quit and view results: ")
        except ValueError:
            print("Please Enter 'y' or 'q'")
        else:
            if quit_command == "q":
                histogram_output()
                break

            elif quit_command == "y":
                pass
                break

            else:
                print("Please Enter 'y' or 'q'")

    return quit_command


progress_outcome_only(pass_credits, defer_credits)
        
            
