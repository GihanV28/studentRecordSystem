# I declare that my work contains no examples of misconduct, such as plagiarism, or collusion. 
# Any code taken from other sources is referenced within my code solution. 
# Student ID: IIT-20210185    UOW-w1867428
# Date: 12/8/2021

import p1 #https://www.w3schools.com/python/python_modules.asp
import p2
import p3
import p4

menu_value = ""
quit_command = ""

print("\n\n","-"*32,"Main Menu","-"*32)
def main_menu():
    global menu_value, quit_command
    while True: 
        print("\n")
        try:
            
            menu_value = input("Enter 1 to open Student Version with validation (Part 1) \n"
                               "Enter 2 to open Staff Version with Histogram (Part 2.1) \n"
                               "Enter 3 to open Staff Version with Vertical Histogtam (Part 2.2) \n"
                               "Enter 4 to open Staff Version (Extention Part 3) \n"
                               "Enter 5 to open Staff Version (Extention Part 4) \n"
                               "Enter 'q' to quit\n")
        except ValueError:
            print("Invalid menu command !")
        else:
            if menu_value == "q":
                print("\nProgram quit succesfully. Have a nice day :) ")
                quit()
            elif menu_value == "1":
                print("\n\nStudent Version (Part 1)")
                p1.validation()
                print("\n\n","-"*32,"Main Menu","-"*32)
            elif menu_value == "2":
                print("\n\nStaff Version (Part 2.1)")
                while True:
                    p1.validation()
                    quit_command = p1.another_one()
                    if quit_command == "q":
                        break
                print("\n\n","-"*32,"Main Menu","-"*32)
            elif menu_value == "3":
                print("\n\nStaff Version (Part 2.2)")
                while True:
                    p2.validation()
                    quit_command = p2.another_one()
                    if quit_command == "q":
                        break
            elif menu_value == "4":
                print("\n\nStaff Version (Part 3)")
                while True:
                    p3.validation()
                    quit_command = p3.another_one()
                    if quit_command == "q":
                        break
            elif menu_value == "5":
                print("\n\nStaff Version (Part 4)")
                while True:
                    p4.validation()
                    quit_command = p4.another_one()
                    if quit_command == "q":
                        break
            else:
                print("Invalid menu command !")
            
                      
                

          
main_menu()

  


                  
