# I declare that my work contains no examples of misconduct, such as plagiarism, or collusion. 
# Any code taken from other sources is referenced within my code solution. 
# Student ID: IIT-20210185    UOW-w1867428
# Date: 12/8/2021

progress_value = 0
trailer_value = 0
retriever_value = 0
exclude_value = 0

pass_credits = 0
defer_credits = 0
fail_credits = 0

progress = []
trailer = []
retriever = []
exclude = []

total_outcomes = 0

table = [progress, trailer, retriever, exclude]

number_range = [ 0, 20, 40, 60, 80, 100, 120]

marks_list = []
list = []
      
    
def progress_outcome(pass_credits, defer_credits ,progress_value, trailer_value, retriever_value, exclude_value):
    
    if pass_credits == 120:
        marks_list=['Progress - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Progress\n")
        progress_value += 1

        
    elif pass_credits == 100:
        marks_list=['Progress (module trailer) - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Progress (module trailer)\n")
        trailer_value += 1

        
    elif pass_credits == 80:
        marks_list=['Module retriever - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Do not Progress - module retriever\n")
        retriever_value += 1

        
    elif pass_credits == 60:
        marks_list=['Module retriever - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Module retriever\n")
        retriever_value += 1

        
    elif pass_credits == 40 and defer_credits == 0:
        marks_list=['Exclude - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Exclude\n")
        exclude_value += 1

        
    elif pass_credits == 40 and defer_credits != 0:
        marks_list=['Module retriever - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Module retriever\n")
        retriever_value += 1

        
    elif pass_credits == 20 and defer_credits <=20:
        marks_list=['Exclude - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Exclude\n")
        exclude_value += 1

    elif pass_credits == 20 and defer_credits >=40:
        marks_list=['Module retriever - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Module retriever\n")
        retriever_value += 1

    
    elif pass_credits == 0 and defer_credits >= 60:
        marks_list=['Module retriever - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Module retriever\n")
        retriever_value += 1

        
    elif pass_credits == 0 and defer_credits <= 40:
        marks_list=['Exclude - ', pass_credits,',' ,defer_credits,',' ,fail_credits]
        list.append(marks_list)
        print("Exclude\n")
        exclude_value += 1



    

def histogram(pass_credits, defer_credits):
    
    if pass_credits == 120:
        progress.append(0)
    elif pass_credits == 100:
        trailer.append(0)
    elif pass_credits == 80:
        retriever.append(0)
    elif pass_credits == 60:
        retriever.append(0)
    elif pass_credits == 40 and defer_credits != 0:
        retriever.append(0)
    elif pass_credits == 40 and defer_credits == 0:
        exclude.append(0)
    elif pass_credits == 20 and defer_credits >= 40:
        retriever.append(0)
    elif pass_credits == 20 and defer_credits <= 20:
        exclude.append(0)
    elif pass_credits == 0 and defer_credits >= 60:
        retriever.append(0)
    elif pass_credits == 0 and defer_credits <= 40:
        exclude.append(0)
    global total_outcomes
    total_outcomes = len(progress) + len(trailer) + len(retriever) + len(exclude)

        
def validation():
    global pass_credits, defer_credits, fail_credits,progress_value, trailer_value, retriever_value, exclude_value
    while True:
        try:
            pass_credits = int(input("Please enter your credits at pass: "))
        except ValueError:
            print ("Integer required\n")
        else:
            if pass_credits not in number_range:
                print("Out of range\n")
            elif pass_credits in number_range:
                break
    while True:
        try:
            defer_credits = int(input("Please enter your credits at defer: "))
        except ValueError:
            print ("Integer required\n")
        else:
            if defer_credits not in number_range:
                print("Out of range\n")
            elif defer_credits in number_range:
                break
    while True:
        try:
            fail_credits = int(input("Please enter your credits at fail: "))
        except ValueError:
            print ("Integer required\n")
        else:
            if fail_credits not in number_range:
                print("Out of range\n")
            elif fail_credits in number_range:
                break
    while True:
        total_credits_value = pass_credits + defer_credits + fail_credits
        if total_credits_value != 120:
            print("Total incorrect\n")
            validation()
            break
        else:
            progress_outcome(pass_credits, defer_credits , progress_value, trailer_value, retriever_value , exclude_value)
            histogram(pass_credits, defer_credits)
            break
        
def histogram_table(table):
    print("Progress", "Trailing", "Retriever", "Excluded")

    for i in range(total_outcomes):
        for x in table:
            if len(x) > 0:
                print("  ", "*", "  ", end="  ")
                x.pop()
            else:
                print("  ", " ", "  ", end="  ")
        print()


def histogram_output():
    print("\n")
    print("-" * 60)
    print("Vertical Histogram\n")
    histogram_table(table)
    print("\n")
    print(total_outcomes, "outcomes in total.")
    print("-" * 60)



def print_info():
    def print_info():
        list.sort()
        for r in list:

            for c in r:
                print(c,end='')
            print()
    with open('inputs_list.txt','a') as filehandle:
        for marks_list in list:
            filehandle.write('%s\n' % marks_list)


quit_command = ""


def another_one():
    global quit_command
    while True:
        print()
        try:
            quit_command = input("Would you like to enter another set of data?\n"
                          "Enter 'y' for yes or 'q' to quit and view results: ")
        except ValueError:
            print("Please Enter 'y' or 'q'")
        else:
            if quit_command == "q":
                histogram_output()
                print_info()
                break

            elif quit_command == "y":
                pass
                break

            else:
                print("Please Enter 'y' or 'q'")

    return quit_command


            
      
            
